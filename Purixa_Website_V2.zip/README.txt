PURIXA WATER SOLUTION - WEBSITE V2
====================================

This version upgrades the existing GitHub Pages website with:
- Premium responsive layout
- 3-slide hero
- Strong Call + WhatsApp buttons
- Services and product cards
- Gallery
- Contact + Google Maps
- Mobile navigation
- SEO title/description
- Faster, cleaner single-page structure

IMPORTANT:
The code uses the existing image filenames from your repository:
Logo.png, slide1.png, slide2.png, slide3.png, technician.jpg,
vogue-g-series.jpg, aqua-2090.jpg, dolphin-gold.jpg, commercial-ro.jpg,
gallery1.jpg, gallery2.jpg, gallery3.jpg.

Before publishing, verify your real business address, phone/WhatsApp numbers,
prices, customer reviews and achievement numbers.

UPLOAD:
Replace index.html, style.css and script.js in your GitHub repository.
Keep all existing image files.
